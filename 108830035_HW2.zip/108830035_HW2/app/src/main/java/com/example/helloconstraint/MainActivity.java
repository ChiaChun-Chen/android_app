package com.example.helloconstraint;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private int mCount=0;
    private TextView mShowCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowCount=(TextView) findViewById(R.id.show_count);
    }

    public void showToast(View view) {
        Toast toast=Toast.makeText(this, R.string.toast_msg, Toast.LENGTH_SHORT);
        toast.show();
    }

    @SuppressLint("ResourceAsColor")
    public void countUp(View view) {
        mCount++;
        if(mShowCount!=null)
            mShowCount.setText(Integer.toString(mCount));
        if(mCount%2==0)
            view.setBackgroundColor(R.color.black);
        else
            view.setBackgroundColor(R.color.teal_200);
        View view1=findViewById(R.id.button_zero);
        view1.setBackgroundColor(R.color.purple_700);
    }

    @SuppressLint("ResourceAsColor")
    public void showZero(View view) {
        mCount=0;
        mShowCount.setText(Integer.toString(mCount));
        view.setBackgroundColor(R.color.gray);
    }
}