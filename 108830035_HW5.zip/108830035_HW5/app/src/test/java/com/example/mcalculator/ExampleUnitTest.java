package com.example.mcalculator;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    private Calculator mCalculator;

    //Set up the environment for testing
    @Before
    public void setUp(){
        mCalculator = new Calculator();
    }
    //Test for simple addition
    @Test
    public void addTwoNumbers(){
        double resultAdd = mCalculator.add(1d, 1d);
        assertThat(resultAdd, is(equalTo(2d)));
    }

    @Test
    public void addTwoNumbersNegative(){
        double resultAddNegative = mCalculator.add(-1d, 2d);
        assertThat(resultAddNegative, is(equalTo(1d)));
    }

    @Test
    public void addTwoNumbersFloats() {
        double resultAddFloat = mCalculator.add(1.111f, 1.111d);
        assertEquals(resultAddFloat, 2.222, 0.001);
    }

    @Test
    public void subTwoNumbers() {
        double resultSub = mCalculator.sub(1d, 1d);
        assertThat(resultSub, is(equalTo(0d)));
    }
    @Test
    public void subWorksWithNegativeResult() {
        double resultSub = mCalculator.sub(1d, 17d);
        assertThat(resultSub, is(equalTo(-16d)));
    }
    @Test
    public void mulTwoNumbers() {
        double resultMul = mCalculator.mul(32d, 2d);
        assertThat(resultMul, is(equalTo(64d)));
    }
    @Test
    public void divTwoNumbers() {
        double resultDiv = mCalculator.div(32d,2d);
        assertThat(resultDiv, is(equalTo(16d)));
    }
//    @Test
//    public void divByZeroThrows() {
//        double resultDiv = mCalculator.div(32d,0);
//        assertThat(resultDiv, is(equalTo(IllegalArgumentException.class)));
//    }

    @Test
    public void powTheNumber(){
        double resultPow = mCalculator.pow(2d, 0);
        assertThat(resultPow, is(equalTo(1d)));
    }

    @Test
    public void powPositiveNumber(){
        double resultPow = mCalculator.pow(2d, 2d);
        assertThat(resultPow, is(equalTo(4d)));
    }

    @Test
    public void powNegativeFirstNumber(){
        double resultPow = mCalculator.pow(-2d, 2d);
        assertThat(resultPow, is(equalTo(4d)));
    }

    @Test
    public void powNegativeFirstNumber2(){
        double resultPow = mCalculator.pow(-2d, 3d);
        assertThat(resultPow, is(equalTo(-8d)));
    }

    @Test
    public void powNegativeSecondNumber(){
        double resultPow = mCalculator.pow(-2d, -2d);
        assertThat(resultPow, is(equalTo(-0.25d)));
    }

    @Test
    public void powZeroForPositiveNumber(){
        double resultPow = mCalculator.pow(0, 2d);
        assertThat(resultPow, is(equalTo(0d)));
    }

    @Test
    public void powZeroForNegativeNumber(){
        double resultPow = mCalculator.pow(0, -1d);
        assertThat(resultPow, is(equalTo(Double.POSITIVE_INFINITY)));
    }

    @Test
    public void powNegativeZeroForNegativeNumber(){
        double resultPow = mCalculator.pow(-0d, -2d);
        assertThat(resultPow, is(equalTo(Double.POSITIVE_INFINITY)));
    }

    @Test
    public void powNegativeZeroForNegativeNumber2() {
        double resultPow = mCalculator.pow(-0d, -3d);
        assertThat(resultPow, is(equalTo(Double.NEGATIVE_INFINITY)));
    }
}