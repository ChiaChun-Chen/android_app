package com.example.mcalculator;

public class Calculator {
    public enum Operator{ADD, SUB, DIV, MUL, POW}

    public double add(double firstOperand, double secondOperand){
        return firstOperand + secondOperand;
    }

    public double sub(double firstOperand, double secondOperand){
        return firstOperand - secondOperand;
    }

    public double div(double firstOperand, double secondOperand){
        if(secondOperand == 0){
            throw new IllegalArgumentException("You cannot divide by zero!");
        }
        return firstOperand / secondOperand;
    }

    public double mul(double firstOperand, double secondOperand){
        return firstOperand * secondOperand;
    }

    public double pow(double firstOperand, double secondOperand){
        double temp = 1;
        if(secondOperand >= 0){
            for (int i = 0; i < secondOperand; i++) {
                temp = temp * firstOperand;
            }
            return temp;
        }else{
            for (int i = 0; i > secondOperand; i--) {
                temp = temp / firstOperand;
            }
            if(firstOperand >= 0){
                return temp;
            }else{
                return -temp;
            }
        }
    }
}
