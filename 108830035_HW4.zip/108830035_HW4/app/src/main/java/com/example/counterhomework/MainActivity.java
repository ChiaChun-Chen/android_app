package com.example.counterhomework;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    public TextView mView;
    private EditText mText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mView = findViewById(R.id.textView);
        mText = findViewById(R.id.edit_text);

        if(savedInstanceState != null){
            boolean isNewCount = savedInstanceState.getBoolean("new count boolean");
            if(isNewCount){
                mView.setText(savedInstanceState.getString("new count"));
                mCount = Integer.parseInt(mView.getText().toString());
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(mText.getText() != null){
            outState.putBoolean("new count boolean", true);
            outState.putString("new count", mText.getText().toString());
        }
        Log.d(".Activity", "onSaveInstanceState");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(".Activity", "onResume");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(".Activity", "stop stop stop");
    }

    public void onCount(View view) {
        mCount++;
        mView.setText(Integer.toString(mCount));
    }
}