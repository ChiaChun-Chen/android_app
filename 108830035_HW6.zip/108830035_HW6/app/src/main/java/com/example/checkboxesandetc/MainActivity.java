package com.example.checkboxesandetc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    String message;
    CheckBox mCheck1, mCheck2, mCheck3, mCheck4, mCheck5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        message = "Tappings:";
        mCheck1 = findViewById(R.id.Chocolate_syrup_checkBox);
        mCheck2 = findViewById(R.id.Sprinkles_checkBox);
        mCheck3 = findViewById(R.id.Crushed_nuts_checkBox);
        mCheck4 = findViewById(R.id.Cherries_checkBox);
        mCheck5 = findViewById(R.id.Orio_cookie_crumbles_checkBox);
    }

    public void displayToast(String message){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    public void showToast(View view) {
        if(mCheck1.isChecked()){
            message = message + ' ' + getString(R.string.chocolate_syrup_text).toString();
        }
        if(mCheck2.isChecked()){
            message = message + ' ' + getString(R.string.sprinkles_text).toString();
        }
        if(mCheck3.isChecked()){
            message = message + ' ' + getString(R.string.crushed_nuts_text).toString();
        }
        if(mCheck4.isChecked()){
            message = message + ' ' + getString(R.string.cherries_text).toString();
        }
        if(mCheck5.isChecked()){
            message = message + ' ' + getString(R.string.orio_cookie_crumbles_text).toString();
        }
        displayToast(message);
        message = "Tappings:";
    }
}