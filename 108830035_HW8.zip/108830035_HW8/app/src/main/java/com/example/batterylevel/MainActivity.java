package com.example.batterylevel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private int batteryLevel;
    private ImageView mBattery;
    static final String BATTERY_LEVEL = "Battery level";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBattery = (ImageView) findViewById(R.id.battery);

        if(savedInstanceState != null){
            batteryLevel = savedInstanceState.getInt(BATTERY_LEVEL);
            mBattery.setImageLevel(batteryLevel);
        }
    }

    public void increase(View view) {
        if(batteryLevel<6){
            batteryLevel++;
        }else{
            batteryLevel = 6;
        }

        mBattery.setImageLevel(batteryLevel);
    }

    public void decrease(View view) {
        if(batteryLevel>0){
            batteryLevel--;
        }else{
            batteryLevel = 0;
        }

        mBattery.setImageLevel(batteryLevel);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt(BATTERY_LEVEL, batteryLevel);
        super.onSaveInstanceState(outState);
    }
}